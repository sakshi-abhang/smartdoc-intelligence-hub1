import io
import os
import re
import hashlib
import base64
import json
import tempfile
import zipfile
from datetime import datetime
from email import policy
from email.parser import BytesParser
from html import unescape
from pathlib import Path

import cv2
import fitz
import numpy as np
import pandas as pd
import streamlit as st
from PIL import Image

try:
    from rapidocr_onnxruntime import RapidOCR
except ImportError:
    RapidOCR = None

try:
    import extract_msg
except ImportError:
    extract_msg = None

try:
    import torch
    from transformers import TrOCRProcessor, VisionEncoderDecoderModel
except ImportError:
    torch = None
    TrOCRProcessor = None
    VisionEncoderDecoderModel = None


# =====================================================
# APP SETTINGS
# =====================================================
st.set_page_config(page_title="SmartDoc Intelligence Hub", page_icon="📑", layout="wide")
CACHE_VERSION = "multiformat_fast_v2"
TEXT_OCR_ZOOM = 0.95
HANDWRITING_ZOOM = 2.0
HEADER_LOGO_BASE64 = "iVBORw0KGgoAAAANSUhEUgAAAQ8AAABVCAYAAABXTWEbAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAABNcSURBVHhe7d15fEzn/gfwz5kkk2Qii0TILrslsWspShE0obXEvq/94YqlC1V63dslVf1ZLkUt1aJClZRq6VVtFW0tpUi0EbIQsUXIJntm7h8ykfOccyYzZ5aM9vt+veblle+ZThPmfPKc73meZzinsOc0IIQQAynYAiGE6IPCgxAiC4UHIUQWCg9CiCwUHoQQWSg8CCGyUHgQQmSh8CCEyELhQQiRhcKDECILhQchRBYKD0KILBQehBBZKDwIIbJwcpfku0e0QYOgYKh8/KCwsWEP17uq8nIUZV1HYXoqCq6msocJIUYyODxUPn4IGTUeKi9f9pDVyk9NQdqubagozGcPEUJkMuiyxd6jESJmz3+iggMAXMObI3LOfCiU9uwhQohM+ocHxyF0zGSrvETRh9LVDQEDBrNlQohMeodHA78ANPBvypZNKtDZvCODxp27gVM8meFHiLXROzxUPn5syeTGhDdiSybFcRycfM3/cxDyd6B3eNh7eLIlk/JS2aGzlzNbNjkHz8ZsiRAig97hwXFsxbQi3FVQ2SoQ5GLeSxdwev/IhBAdrOZMinBX8f4khFg3KwoPR96fhBDrZhXhoVRwCHFxAGjkQcgTwyrCI9JDVdNT8XVSwkVJt1MJsXYmCQ9nI092drQRaeTow8HGJD8WIUQHk5xlthyHpc8EoLefK3tIL2yfo6XMvsegIHcsecoPpVVq9hAhxMRMEh4Pyiqx+Y+7mN/OB1t6haCXn6tBt3bZkUcrA0YeSgWHIcHu2N0vHOOaeeLDpNvsUwghZqD3qtqA/oPg/VwftszT198NC9r7AACyisqxIzUHR27kQ6Pj/xDkYo/NPUN4tSqNBtEHUlCl4z+0t+HwYpA7RoR6oKG9LSrVGsw5kYmUByXsU3nSdm3DvbOn2LLR4iYNw3sLZ7Jl5OUXIrjLEJRXVLKH6qS0s0X6L4lwcxVOnus0YAoupaazZUlS35/W1NfisWv/d2xZUlCAD5KO7GDLJuHWIgqVVVU1X29cthCjB/XlPUeuktIynL2YggXxa3HhjyvsYQBAzy4dsOTlqYgID4Kjg/x5R/fzCrD3mx/x6jurUSUyGp49eTjiX5/BltGkbQweFut+H4cF+ePrrcvh6yWcvKlWazDnnyvwye6v2UMmZZKRh9bhrDzsz3gAAPBvoMTr7X2xtXcong9wg0JiJMKOOgDAhuMQ7vbo7gvLwUaBUWGNkNAnHNMjmqChvS0AYPn5W3UGR31wc3XG+GH92bJexg+NEQ0OQykUHGZNGsaWeeZOHcmWrIbEW0cWRwd7dHu6Db7//EMEBTz6RVdb+8hm2L/lA3Rs3dyo4AAAdzcXTBszEGvefpU9ZJRO7SLw0571osHxsLgEQ6YtMHtwwNThAQAfJvFPYl8nJV5r54PtUWHo37QhbJjrGbbfocWGispWgbHhjbCrbximtmwMN/vHTdoDmQ9wOCuP93xrMnfqCHCGXMdVr8OZO800J/TAfj1E32i1RTYLxrOd2rJlqyA9/pTPwV6JRXET2TLGxUZDIfWbTqbxQ6PRPNQ0i0oHRHXFwe0r4eLsxB7CzTv30GPoDBw5foY9ZBYmDw+1Blh06jpyS/nDdC+VHV5u643P+oTixaCGsK3+B2JDQksbKk52Ckxo7omdfcMwqUVjwZ2dlAclVt/nCPTzxgtR3diyTtE9n0GgnzdblmXWxKFsSVRcHaOTv5rgpsJ9aXzqCFm5IsKD2ZLB4iYNw861b8NeacceQvLldHQb/BJSrl5jD5mNSXsetYW5OmB19yAoJVI8t7QSien3Ma2l+EK13NJKHM7Kw6AgdzjaimdcTkkFpv+Ujryyx9fHdbF0z0Pr1LlL6D1yFluWdGj7Sp0jAX17Hk+1aYEfv1jHlpF9O0d0NNK6z1ikX8tmywKBft5I/iGBLeP8pSsoeljMlg3Sf8LLvB6BWM+j6GExzl8S71mICQ3yg5enB6+WfDkdnV+Ywqvt3bQU/Xp04tVu3c1FWuYNXk2Xrk+1Fow0Zyxchu17D/Fq+vY8OI7DyiVzMHX0QN7ztI4cP4PRs95EcUkZe8iszBYeAPCcrwve7GieJfAVag1mHcvA1fxS9pBO9RUeANAjdgbOJqWwZYHIZsE4eeBjtsyjb3hsXfVPxMb05NUKi4oRM34ejidu4NUBYNOO/Zj371VsWUCqYdpz2EycufAnWzbKpmULMYoJj7NJKegRKzzxpKx++xVMHjGAV7uUmo5OA/jhkbh5Kfp254fH5oT9mPuvuv9OtHKTDwtGBzPfWIZtewwPD3ulHbauWoIBUV3ZpwEA1m9LxIL4D6FW63Uam5T4r3QTOZpdgMT0+2zZJJaeyzY4OOrbK9NHsyVR86aNYkuy+Hp5YvDzz7FlbPn8AH5PTsX3J35jD2Fs7PMmadL+nS1btx3xa7byHhf+uMo+rU4uzk44uH2laHCo1RrELV6O195ZUy/BAXOHBwCsT76N5FzjhrGsxPT7OJpdwJat3gtR3ersY3h6uCG2P3+kINc/Jg4VNP/Uag3Wbd0LAFi3dQ/vGKrvRkwb9SJbJgZ4f912xK/5lPeQui0sJcC3CX7asx6d2kWwh1BcUmaxOyq6mD081Bpg8eks5JRUsIdkSc4txvpk626QSuE4DnOnjmDLPHGThsPWBPvEqhztBcN0ADj4wy/Ivp0DADh87DQysm6xT8HMCUNN8j0Q3TQS85haNQ/Bsb0fISzInz2Eu/ceoNfwmRa7o6KLWXsetQW52GN9j2DYSTRQ9ZFTUoFpR9NRWK5/g5Rlrp7HrEnDsJTpeVRWVQlOwpLSMoQ9Owx5+YW8OqpP+Ksn9gpuw4m9ztMDJuOP1AxerbaZE2KxbJGwQTtgwis4+uu5mq9fGjMIK5bM4T0HAF6a/x4S9h1myzVM3TD97vhpLN8gfD1YuOdhioapVtbNO9jzzQ/470/i7zex9wwAlJaVw8FeyZaRlJKGwVMW4HZOLnuoXph95KHlo1IKbt8a6m5JBXxUwr9Ua5WWeQOp6dd5NUcHe0wfK76L+7jYGEFw/HzmomjQcDqmTikUHGaMj2XLuJx2jRccAPBZ4iHRk332FN0jJE7il0DbiDB0e7qNwY/w4AD2pWqI/XZzdlLh2U5t9X54ebqzLyE687msvJwtwbuxh+D71ecxalBf7N20FPNnjGVfUiex4Dhz4U9EjYyzmuCAucOD44Befq7Y1DMYb3Xyh5dKeH/aEBHuKqzrEYQPujRFe0/hJBlr9J+PP2dLmDVxKJR2j2bGaikUHOImC+dZrBXpS9RlQO9uCPIX9lbWb0tkSyguKcPHuw6wZUQ2C0aPzu3YstUIDw7Aoe0r9X7E9OrCvgTUauGU8fPJpv90wUWzJ8GniXBzb4UBEwdbtwjFU21asOV6ZZbwsFNwGBDYENt6h2JRB18EV2/0YyrtPZ3wQZemWNs9CF29nXX8Dq5/u/Z/hwfMyMHN1RnjYqN5tQG9hc3U7Ns5+PrICV5NH2IhVFhUjIR9/2XLAIB1W/eKduzjJg9nS/XCXP++f17JZEvYsGMf7uSY9g6hjY0CbSPC2TLUYkOf6ssWlr3SDvu2LBO981JfTBoeDjYKDA/1wI4+YZjXxhs+TsLhlyk1b+iIt572x8e9QtDH31Vy/Ux9KiuvwEfbv2TLmPfSKN5EotlThCeq1EmtS6vmIXimQyu2jE+/+EZyElH27Rwc+O44W0a/Hp0Egaalkfi+zl+6ghOnLxj8YC/vzK28ohLLNwp7LPkFRegzeja+PXpS8D3q+xBrhHo0FG5XIfV2HT59kejCOFsbG3y25t9WEyAmaZg6K20QG+yOQcHucLarvy797eIK7L56D4eu5aFc4s1troap2CSx1PTraP/8BHh6uOHKiT2CpufImYvx9ZGfRSeFFZeUIbjLEBQ9LEbmyS/RyN2Nd1xqktjH/78II16MYsu4lJqOB3nC3omWV2MPhAYKJ/Rt3vkV5i5ZyZYtOklMbIapMS6nXcOC+LVmu2Oh7yQxsfcMADRpE43moYE4uH0FnFTCtV9qtQYT5r2FLw8dZQ9ZlFEjDw8HW8yM9MKuvmEY18yzXoMD1etnZrf2RkLfMIwKawSVxLR2S8vJzRNd7j6nuin5mkhDbUfit6KNTF18vTwl54hEhAcLGnq1H2LBAROu7DW1pJQ0RI+bJ3jEjH+55lZ0bTdu3UWTtjFoEN4THaInmi04DMFOYa/BcTiblIKYcS+jsEj4HlAoOGxb9U+MH8q/9LU0WWeXr5MSr7b1QUKfMMSGuFvdtn8N7W0xtWVj7Oobjikt+Ctw68uKjTvZEp7p0AovRHUTzALVaDRYvUXYaK3L/40dLBjdGEtpZyt5d8hSxE6x/IIiHD91XvA4dvJ3zHxjGft0+Hk3xrsLprNlgXaR4YI7NSESwWoIkSuZOp1NSkG/MXNEA4TjOKyLny+53sUSZF22hLk6QCVzlOFgwyG+s/RtOTH3yyrxzm91L9aScq+kAtkPHzWhzHXZInbPPuXqNXSMebzs++C2FejO3MEoK68QDHEPHzuFIVNfr/k649cv4enBv2xh53moHO2R/ksiGjiJr1I2Rk5uHpp1H8bb0MiSly1i8zxOnL6A58fO5dVq27ZqCYbECKfm9xk1G7+eTWLLNX7etxFtWobxavW5tgXVd1oOblshOQJcEL8Waz81/K6csWSFhzHaNnLC8q6G720w+NBlFBgxOUzLXOEhdv2q7XloxfTqgt0fvct7jphBU+bzhtX69DymjRmIlUuEJ9Oeb35AanoWW5bUIrQpBkcLT7rpr7+PzxK/rfk6yN8bSd8LG46ffvENbt6+x5YNsnzDDpSVP56RLCc83N1ckPx9gmDezPXsO+gQPQElpeLNY7HwOJd8Gd/+eJJX02XBzHGwYUbjxoQHALQIC8R3CaslA+TRNPitbNmsLB4eY8MbYVIL8WX4uiw+lYVfb0s3/PRVn+HBcRwuHtkhOgdDKyPrFlr15i+gqys8pF63uKQMgZ0HSt5lEePcQIW0nxOhcuTvonUlIwvt+o2v+Vpq5GEK3u3784bqcsID1ZvwrIufz5ax5pMvsPA94TYFAHA8cQPaRQpvqxpr2vz3sJOZsWtIeKA6QL79bJXonRsAWPvpHiyIX8uWzcbizYpID+lh9RdXpWfPSe049iTRaDRYs2U3W+b5z+ZdbKlOMb2eEQQHqmePGhIc0M4H+fLxCEMrLMgfvbp2ZMtWbdueQzhx+gJbxqyJQ9GxdXO2DAC4c8+0czy0cnIfbc9pjD+vZCJqZBxyH+Szh4DqhZCr/qU7UE3JouHBcdI7h628cAsfXbpTswcqy5Ad1a2Z1HRwVG9wIzWRS5dZE4WTwlD9G1YOsVmxeEJ3Gpv++vu8SyBUj9S2LF8s2lw+LLEOxRjXs+/g5zMX2bIsVzKyEDUyDnfviZ8nU0cPxLr4+dJ3ckzIouER6Gwvevv0cFYevs589JfB7oGq1cLdUbD/6ZOouKQMmxK+YssAgE0JXxk8UmjVPER0x7FjJ39HxvWbbFkvGVm38OMvZ9ky+nR/WnSlpzXLvHEL767+hC0juKkvFsY9vqTU2pSwXzI85ci6eRejZ70p2WOR40pGFnqP+IdkgIwfGo3NH7xh9gCxaM/jhcCGmNuGP7xOeVCCOScyUVlrUpebvQ02PhcCDwf++o+44xn4474wWAxhrp6Hr5enYE/M4uJS0Z3DXF0aoHWLULaMpJQ00UVwndpHQGnH796fu5iChyWl8PNuLLoLeGbWTWTdvMuW9Sb1uunXspF9OwcO9ko81bYle9gkfvntIm8bwvDgADRhFrblFxTh4p/6bbBjY6NAl46t2TIqK6sk77w4N1ChWXAAHB3lL60oKHyI5Mtpoh+7AIn3DER+finejT0QqiPMk1PSBEsjTMmi4bGwvS+i/B83e3JLK/HS0TTRPUhDXR3wYfcg3hL+DZfuYLeOvog+zBUehPzdCK8hzKh2s7RSrcEbJ6+LBgcAXM0vxdJz/Lkdxn6GLSHEdCwWHi5KG96S/OXnb9W5Bym7B2orHXdqCCGWZbHwaNvo8WSdfRn39f6Qptp7oLoobeBr5pW6hBD9WCw8tJccybnFWGvAhzSxe6DqmidCCLEcy4WHhyNySyux+HQWJFbLSyosr8LCk9dRodZQ34MQK2GR8FAqOAQ6O+CNk9dlb16cUVCGpeeyEenx5M80JeSvwCLh0dJdhWW/G/8hTUezC3D6TpHoRDNCiGXpfRaWF8r/kKXMwjKTfUjT+uQ7UNrInzlXUSC+LoAQYhi9w6M4W/9l3ay8MuM+coElNTdEH0VZlvsUcUL+yvQOj8KMdJTm3GHLT5T7F86hqtS46e2EkEf0Dg+Nugppu7ez5SeGuqIcmV/JW2VKCBHSOzwAoCgzA5l7d6KKWeJs7SoKCpC6dSMqCkzTdyGEGLAwrjalqxu8e0TBOSgETn6G7UdqKVXlFSi+cQ35V1Nx69j3UJcZd6eHEMInKzwIIcSgyxZCCNGi8CCEyELhQQiRhcKDECILhQchRBYKD0KILBQehBBZKDwIIbJQeBBCZKHwIITIQuFBCJGFwoMQIguFByFEFgoPQogsFB6EEFkoPAghsvwPf7Y65wfhBPoAAAAASUVORK5CYII="

ALL_FIELDS = [
    "Document Type",
    "Ship From",
    "Ship To",
    "Notify Party",
    "Date",
    "Our Ref. No.",
    "Vessel/Truck",
    "Carrier",
    "Carrier Name",
    "SCAC",
    "Loading Port",
    "Discharge Port",
    "Location",
    "Origin/Destination Port",
    "Sales Order No.",
    "Shipment Number",
    "Forwarding Agent",
    "Shipping Line",
    "B/L or AWB No.",
    "Bill of Lading",
    "Arrival/Departure Date",
    "Free Time Exp.",
    "Delivery Type",
    "House No.",
    "Entry-B/L No.",
    "Customer Ref. No.",
    "PO/PRO Number",
    "VRET ID",
    "RA Number",
    "Deliver To",
    "Shipping Marks",
    "Delivery Numbers",
    "Item Numbers",
    "No. of Packages",
    "Description of Articles",
    "Bill of Lading Description",
    "Pallets",
    "Cartons",
    "Units",
    "Weight",
    "Volume",
    "Total Charges",
    "FOB Value",
    "Currency",
    "Total Bundles",
    "Total Pieces",
    "Total Net Weight",
    "Total Gross Weight",
    "Bill of Lading Instructions",
    "HS Code",
    "Container No.",
    "Container Numbers",
    "Container Size/Type",
    "Container Types",
    "Booking Number",
    "Trailer Number",
    "Seal No.",
    "Seal Numbers",
    "Quantity",
    "Total Containers",
    "Source Type",
    "Sheet Name",
    "Email Subject",
    "Email From",
    "Email To",
    "Email Date",
    "Email Attachments",
    "Extracted Text",
    "Detected Key-Value Pairs",
    "Handwritten Text",
    "Length",
    "Width",
    "Height",
]

st.markdown(
    """
    <style>
    .stApp { background: #F4F7FB; }
    .block-container { max-width: 1380px; padding: 1rem 2rem 3rem 2rem; margin: 0 auto; }
    header[data-testid="stHeader"] { background: transparent; }
    h1, h2, h3 { color: #082A46 !important; }

    .app-header {
        background: #0B2540;
        border-radius: 16px;
        padding: 20px 28px;
        color: white;
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 12px;
        box-shadow: 0 8px 25px rgba(3, 26, 46, 0.24);
    }
    .brand-area { display: flex; align-items: center; gap: 16px; }
    .brand-divider { width: 1px; height: 58px; background: rgba(255,255,255,0.32); margin: 0 4px; flex: 0 0 1px; }
    .brand-icon {
        width: 175px;
        height: auto;
        display: block;
        object-fit: contain;
        background: #0B2540;
        mix-blend-mode: normal;
    }
    .brand-title { font-size: 23px; line-height: 1.1; font-weight: 750; }
    .brand-subtitle { color: #C9DFEC; font-size: 12.5px; margin-top: 5px; }
    .header-status {
        background: rgba(255, 255, 255, 0.10);
        border: 1px solid rgba(255, 255, 255, 0.20);
        border-radius: 11px; padding: 9px 15px; min-width: 205px;
    }
    .status-label { color: #AFC9D9; font-size: 11px; text-transform: uppercase; letter-spacing: 0.8px; }
    .status-value { color: white; font-size: 14px; font-weight: 650; margin-top: 3px; }

    .step-navigation {
        background: white; border: 1px solid #DEE7EF; border-radius: 14px;
        display: flex; align-items: center; padding: 5px 10px;
        margin-bottom: 22px; overflow-x: auto;
        box-shadow: 0 2px 8px rgba(8, 42, 70, 0.04);
    }
    .step-item {
        padding: 13px 22px; color: #627384; font-size: 14px;
        font-weight: 600; white-space: nowrap; border-bottom: 3px solid transparent;
    }
    .step-item.active { color: #0878B9; border-bottom-color: #1598C6; }
    .step-number {
        display: inline-flex; align-items: center; justify-content: center;
        width: 24px; height: 24px; margin-right: 7px; border-radius: 50%;
        background: #E8F5FA; color: #0878B9; font-size: 12px; font-weight: 750;
    }
    .step-item.active .step-number { color: white; background: #1598C6; }
    div[data-testid="stHorizontalBlock"] .workflow-nav div.stButton > button {
        background: transparent;
        color: #627384;
        border: none;
        border-radius: 0;
        box-shadow: none;
        min-height: 58px;
        padding: 10px 16px;
        font-size: 14px;
        font-weight: 700;
    }
    div[data-testid="stHorizontalBlock"] .workflow-nav div.stButton > button:hover {
        background: #F7FBFD;
        color: #0878B9;
        transform: none;
    }

    .workflow-bar { max-width: 1180px; margin: 0 auto 18px auto; }
    .workflow-bar div.stButton > button {
        min-height: 42px !important;
        padding: 7px 12px !important;
        border-radius: 9px !important;
        font-size: 13px !important;
        font-weight: 700 !important;
        white-space: nowrap !important;
    }
    .workflow-bar div.stButton > button[kind="primary"] {
        background: linear-gradient(135deg, #0878B9, #149FC7) !important;
        color: white !important;
        border: none !important;
        box-shadow: 0 4px 12px rgba(8,120,185,.16) !important;
    }
    .workflow-bar div.stButton > button[kind="secondary"] {
        background: #EAF4F8 !important;
        color: #526878 !important;
        border: 1px solid #D5E5ED !important;
        box-shadow: none !important;
    }
    .workflow-bar div.stButton > button:disabled {
        background: #EEF3F6 !important;
        color: #A4B0B9 !important;
        border: 1px solid #E1E8ED !important;
        cursor: not-allowed !important;
        box-shadow: none !important;
    }
    .page-title-compact {
        max-width: 1180px;
        margin: 4px auto 16px auto;
        color: #082A46;
        font-size: 27px;
        line-height: 1.2;
        font-weight: 750;
    }
    .page-title-compact .step-circle {
        display: inline-flex; align-items: center; justify-content: center;
        width: 29px; height: 29px; margin-right: 9px;
        border: 2px solid #082A46; border-radius: 50%;
        font-size: 14px; vertical-align: 3px;
    }
    .section-title { color: #082A46; font-size: 20px; font-weight: 750; margin-bottom: 4px; }
    .section-description { color: #6A7B8C; font-size: 13px; margin-bottom: 18px; }
    .content-card {
        background: white; border: 1px solid #DEE7EF; border-radius: 15px;
        padding: 23px 24px; margin-bottom: 18px;
        box-shadow: 0 3px 12px rgba(8, 42, 70, 0.05);
    }
    [data-testid="stFileUploader"] {
        background: #F9FCFE; border: 2px dashed #55B4D5;
        border-radius: 13px; padding: 12px;
    }
    [data-testid="stFileUploader"]:hover { border-color: #0878B9; background: #F2FAFD; }
    div[data-baseweb="input"] > div { border-radius: 9px; border-color: #D5E1E9; }

    .stButton > button {
        background: linear-gradient(135deg, #0878B9, #149FC7);
        color: white; border: none; border-radius: 9px; min-height: 44px;
        padding: 0 22px; font-weight: 650;
        box-shadow: 0 4px 12px rgba(8, 120, 185, 0.20);
    }
    .stButton > button:hover {
        color: white; border: none;
        background: linear-gradient(135deg, #07699F, #0D89AD);
    }
    .stDownloadButton > button {
        background: linear-gradient(135deg, #11998E, #18B8A5);
        color: white; border: none; border-radius: 9px; min-height: 46px;
        padding: 0 22px; font-weight: 650;
        box-shadow: 0 4px 12px rgba(17, 153, 142, 0.20);
    }
    .stDownloadButton > button:hover {
        color: white; border: none;
        background: linear-gradient(135deg, #0D857C, #13A594);
    }
    div[data-testid="metric-container"] {
        background: white; border: 1px solid #DEE7EF; border-radius: 14px;
        padding: 17px 18px; box-shadow: 0 3px 10px rgba(8, 42, 70, 0.04);
    }
    div[data-testid="stMetricValue"] { color: #0878B9; font-weight: 750; }
    [data-testid="stDataFrame"], [data-testid="stDataEditor"] {
        background: white; border: 1px solid #DEE7EF; border-radius: 12px; overflow: hidden;
    }
    .stTabs [data-baseweb="tab-list"] {
        gap: 8px; background: #EDF3F7; border-radius: 11px; padding: 5px;
    }
    .stTabs [data-baseweb="tab"] {
        height: 43px; padding: 0 16px; border-radius: 8px;
        color: #536779; font-weight: 600;
    }
    .stTabs [aria-selected="true"] {
        background: white !important; color: #0878B9 !important;
        box-shadow: 0 2px 8px rgba(8, 42, 70, 0.08);
    }
    div[role="radiogroup"] { background: #F0F5F8; border-radius: 10px; padding: 6px 10px; }
    .preview-heading {
        display: flex; align-items: center; gap: 8px; color: #082A46;
        font-size: 18px; font-weight: 750; margin-bottom: 12px;
    }
    .workspace-ribbon {
        display:flex; gap:10px; flex-wrap:wrap; margin: 2px 0 18px 0;
    }
    .workspace-chip {
        background:#E8F5FA; color:#0878B9; border:1px solid #BFE5F2;
        border-radius:999px; padding:7px 12px; font-size:12px; font-weight:700;
    }
    .quality-card {
        background:linear-gradient(135deg,#FFFFFF,#F5FAFD); border:1px solid #DCE8F0;
        border-radius:14px; padding:16px; min-height:92px;
    }
    .quality-label { color:#63788A; font-size:12px; text-transform:uppercase; letter-spacing:.5px; }
    .quality-value { color:#0B2540; font-size:24px; font-weight:800; margin-top:4px; }
    .review-ok { color:#087F5B; font-weight:700; }
    .review-needed { color:#B26A00; font-weight:700; }
    .app-footer {
        margin-top: 32px; padding: 16px; border-top: 1px solid #DCE5EC;
        color: #758695; text-align: center; font-size: 12px;
    }
    @media (max-width: 800px) {
        .block-container { padding: .75rem 1rem 2rem 1rem; }
        .app-header { align-items: flex-start; flex-direction: column; gap: 16px; }
        .header-status { width: 100%; }
        .step-item { padding: 9px 10px; }
        .workflow-bar div.stButton > button { font-size: 11px !important; padding: 6px !important; }
    }
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    f"""
    <div class="app-header">
        <div class="brand-area">
            <img class="brand-icon" src="data:image/png;base64,{HEADER_LOGO_BASE64}" alt="MAERSK">
            <div class="brand-divider"></div>
            <div>
                <div class="brand-title">SmartDoc Intelligence Hub</div>
                <div class="brand-subtitle">Multi-format extraction, quality review, and export workspace</div>
            </div>
        </div>
        <div class="header-status">
            <div class="status-label">Extraction Engine</div>
            <div class="status-value">Extraction + Quality Intelligence</div>
        </div>
    </div>
    """,
    unsafe_allow_html=True,
)


# =====================================================
# GENERAL HELPERS
# =====================================================
def clean(value):
    return re.sub(r"\s+", " ", str(value or "")).strip(" :-|\t\r\n")


def multiline_clean(value):
    lines = [clean(line) for line in str(value or "").splitlines()]
    return "\n".join(line for line in lines if line)


def empty_fields():
    return {field: "" for field in ALL_FIELDS}


def normalize_label(value):
    return re.sub(r"[^A-Z0-9]", "", str(value or "").upper())


def detect_document_type(text):
    upper = str(text or "").upper()
    if "SHIPPING INSTRUCTION / INVOICE" in upper:
        return "Shipping Instruction / Invoice"
    if "DELIVERY ORDER" in upper:
        return "Delivery Order"
    if "BILL OF LADING" in upper or "BILL OFLADING" in upper:
        return "Bill of Lading"
    if "INVOICE" in upper:
        return "Invoice"
    return "PDF Document"


def first_match(text, patterns, flags=re.IGNORECASE | re.MULTILINE):
    for pattern in patterns:
        match = re.search(pattern, text, flags)
        if match:
            return clean(match.group(1))
    return ""


def block_between(text, start_pattern, stop_patterns):
    start = re.search(start_pattern, text, re.IGNORECASE)
    if not start:
        return ""
    remaining = text[start.end():]
    positions = []
    for pattern in stop_patterns:
        stop = re.search(pattern, remaining, re.IGNORECASE)
        if stop:
            positions.append(stop.start())
    end = min(positions) if positions else len(remaining)
    return multiline_clean(remaining[:end])


def render_page_rgb(page, zoom):
    pix = page.get_pixmap(
        matrix=fitz.Matrix(zoom, zoom), colorspace=fitz.csRGB, alpha=False
    )
    return np.frombuffer(pix.samples, dtype=np.uint8).reshape(
        pix.height, pix.width, 3
    ).copy()


# =====================================================
# GENERIC CONTENT HELPERS
# =====================================================
def strip_html(value):
    text = re.sub(r"(?is)<(script|style).*?>.*?</\\1>", " ", str(value or ""))
    text = re.sub(r"(?s)<[^>]+>", " ", text)
    return clean(unescape(text))


def extract_generic_key_values(text, limit=80):
    pairs = []
    seen = set()
    for raw_line in str(text or "").splitlines():
        line = clean(raw_line)
        if not line or len(line) > 500:
            continue
        match = re.match(r"^([A-Za-z][A-Za-z0-9 /_.()#&-]{1,80})\\s*[:=-]\\s*(.{1,350})$", line)
        if not match:
            continue
        key = clean(match.group(1))
        value = clean(match.group(2))
        normalized = key.lower()
        if value and normalized not in seen:
            pairs.append(f"{key}: {value}")
            seen.add(normalized)
        if len(pairs) >= limit:
            break
    return "\\n".join(pairs)


def make_general_row(source_type, text="", document_type="Document", **metadata):
    fields = empty_fields()
    fields["Document Type"] = document_type
    fields["Source Type"] = source_type
    fields["Extracted Text"] = multiline_clean(text)
    fields["Detected Key-Value Pairs"] = extract_generic_key_values(text)
    for key, value in metadata.items():
        if key in fields:
            fields[key] = clean(value)
    return fields


# =====================================================
# PRINTED OCR WITH POSITIONS
# =====================================================
@st.cache_resource(show_spinner="Loading printed-text OCR...")
def get_rapidocr():
    if RapidOCR is None:
        return None
    try:
        threads = max(1, min(4, os.cpu_count() or 2))
        return RapidOCR(intra_op_num_threads=threads)
    except Exception:
        return RapidOCR()


def _rapidocr_lines_from_image(engine, image):
    result, _ = engine(image, use_cls=False)
    lines = []
    for item in result or []:
        try:
            box, text, confidence = item[0], clean(item[1]), float(item[2])
            if not text:
                continue
            xs = [float(point[0]) for point in box]
            ys = [float(point[1]) for point in box]
            lines.append(
                {
                    "x0": min(xs), "y0": min(ys),
                    "x1": max(xs), "y1": max(ys),
                    "cx": (min(xs) + max(xs)) / 2,
                    "cy": (min(ys) + max(ys)) / 2,
                    "text": text, "confidence": confidence,
                    "page_width": image.shape[1],
                    "page_height": image.shape[0],
                }
            )
        except (TypeError, ValueError, IndexError):
            continue
    lines.sort(key=lambda line: (line["cy"], line["x0"]))
    return lines


def run_rapidocr(page):
    engine = get_rapidocr()
    if engine is None:
        return "", []

    # Fast pass. Most clean printed scans are readable below 1x render scale.
    fast_zoom = min(TEXT_OCR_ZOOM, 0.95)
    image = render_page_rgb(page, fast_zoom)
    lines = _rapidocr_lines_from_image(engine, image)
    text = "\n".join(line["text"] for line in lines)

    # Accuracy fallback runs only when the fast pass found too little usable text.
    usable_characters = len(re.sub(r"[^A-Za-z0-9]", "", text))
    average_confidence = (
        sum(line["confidence"] for line in lines) / len(lines) if lines else 0.0
    )
    if usable_characters < 45 or average_confidence < 0.55:
        fallback_zoom = 1.55 if TEXT_OCR_ZOOM < 2.0 else 2.0
        fallback_image = render_page_rgb(page, fallback_zoom)
        fallback_lines = _rapidocr_lines_from_image(engine, fallback_image)
        fallback_text = "\n".join(line["text"] for line in fallback_lines)
        if len(re.sub(r"[^A-Za-z0-9]", "", fallback_text)) > usable_characters:
            return fallback_text, fallback_lines

    return text, lines



def run_rapidocr_image(image_rgb):
    engine = get_rapidocr()
    if engine is None:
        return "", []
    result, _ = engine(np.asarray(image_rgb), use_cls=False)
    lines = []
    for item in result or []:
        try:
            box, text, confidence = item[0], clean(item[1]), float(item[2])
            if not text:
                continue
            xs = [float(point[0]) for point in box]
            ys = [float(point[1]) for point in box]
            lines.append(
                {
                    "x0": min(xs), "y0": min(ys),
                    "x1": max(xs), "y1": max(ys),
                    "cx": (min(xs) + max(xs)) / 2,
                    "cy": (min(ys) + max(ys)) / 2,
                    "text": text, "confidence": confidence,
                    "page_width": image_rgb.shape[1],
                    "page_height": image_rgb.shape[0],
                }
            )
        except (TypeError, ValueError, IndexError):
            continue
    lines.sort(key=lambda line: (line["cy"], line["x0"]))
    return "\\n".join(line["text"] for line in lines), lines


def find_positioned_label(lines, alternatives):
    targets = [normalize_label(value) for value in alternatives]
    for line in lines:
        compact = normalize_label(line["text"])
        if any(target in compact for target in targets):
            return line
    return None


def lines_in_region(lines, x0, y0, x1, y1):
    selected = [
        line for line in lines
        if x0 <= line["cx"] < x1 and y0 <= line["cy"] < y1
    ]
    selected.sort(key=lambda line: (line["cy"], line["x0"]))
    return selected


def region_text(lines, x0, y0, x1, y1, exclusions=()):
    output = []
    exclusion_targets = [normalize_label(value) for value in exclusions]
    for line in lines_in_region(lines, x0, y0, x1, y1):
        compact = normalize_label(line["text"])
        if any(target in compact for target in exclusion_targets):
            continue
        output.append(line["text"])
    return "\n".join(output)


def inline_value(text, labels):
    for label in labels:
        match = re.search(
            rf"(?im)^\s*{label}\s*[:#-]?\s*(.*?)\s*$",
            text,
        )
        if match and clean(match.group(1)):
            return clean(match.group(1))
    return ""


# =====================================================
# AMAZON / MAERSK SCANNED BILL OF LADING
# =====================================================
def extract_amazon_bol(text, lines):
    fields = empty_fields()
    fields["Document Type"] = "Bill of Lading"
    if not lines:
        return fields

    page_width = lines[0]["page_width"]
    page_height = lines[0]["page_height"]
    left_boundary = page_width * 0.52

    ship_from_label = find_positioned_label(lines, ["SHIP FROM", "SHIPFROM"])
    ship_to_label = find_positioned_label(lines, ["SHIP TO", "SHIPTO"])
    vret_label = find_positioned_label(lines, ["VRET ID", "VRETID"])

    if ship_from_label and ship_to_label:
        fields["Ship From"] = region_text(
            lines,
            0,
            ship_from_label["y1"] + 1,
            left_boundary,
            ship_to_label["y0"] - 1,
            exclusions=("Bill of Lading", "ID"),
        )

    if ship_to_label:
        ship_to_end = (
            vret_label["y0"] - 1
            if vret_label and vret_label["y0"] > ship_to_label["y1"]
            else ship_to_label["y1"] + page_height * 0.16
        )
        fields["Ship To"] = region_text(
            lines,
            0,
            ship_to_label["y1"] + 1,
            left_boundary,
            ship_to_end,
            exclusions=(
                "Carrier Name", "SCAC", "PRO Number", "Trailer Number",
                "Seal Number", "VRET ID", "RA Number",
            ),
        )

    fields["Carrier Name"] = inline_value(text, [r"CARRIER\s*NAME"])
    fields["Carrier"] = fields["Carrier Name"]
    fields["SCAC"] = inline_value(text, [r"SCAC"])
    fields["PO/PRO Number"] = inline_value(
        text, [r"PRO\s*NUMBER", r"PRC\s*NUMBER", r"PO\s*NUMBER"]
    )
    fields["Trailer Number"] = inline_value(text, [r"TRAILER\s*NUMBER"])
    fields["Seal No."] = inline_value(text, [r"SEAL\s*NUMBER"])
    fields["VRET ID"] = inline_value(text, [r"VRET\s*ID"])
    fields["RA Number"] = inline_value(text, [r"RA\s*NUMBER"])

    uuid = re.search(
        r"\b[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}\b",
        text,
        re.IGNORECASE,
    )
    if uuid:
        fields["Bill of Lading"] = uuid.group(0)

    # Preserve the source's printed date including time, but keep it as one clean value.
    date = re.search(
        r"DATE\s*:\s*((?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)\s+"
        r"(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+"
        r"\d{1,2}\s+\d{2}:\d{2}:\d{2}\s+UTC\s+\d{4})",
        text,
        re.IGNORECASE,
    )
    if date:
        fields["Date"] = clean(date.group(1))

    weight = re.search(r"\b([0-9]+(?:\.[0-9]+)?)\s*pounds\b", text, re.IGNORECASE)
    volume = re.search(r"\b([0-9]+(?:\.[0-9]+)?)\s*cuft\b", text, re.IGNORECASE)
    fields["Weight"] = f"{weight.group(1)} pounds" if weight else ""
    fields["Volume"] = f"{volume.group(1)} cuft" if volume else ""

    # Numeric table values located between labels and the legal text.
    table_start = find_positioned_label(lines, ["STACKABLE"])
    legal_start = find_positioned_label(lines, ["If the shipment moves"])
    if table_start:
        max_y = legal_start["y0"] if legal_start else table_start["y1"] + page_height * 0.07
        numeric_lines = lines_in_region(lines, 0, table_start["y1"], page_width, max_y)
        numbers = [line["text"] for line in numeric_lines if re.fullmatch(r"[0-9]+", line["text"])]
        if len(numbers) >= 4:
            fields["Pallets"] = numbers[0]
            fields["Cartons"] = numbers[2]
            fields["Units"] = numbers[3]

    fields["Total Charges"] = "USD" if re.search(r"\bUSD\b", text) else ""
    return fields


# =====================================================
# FLEXPORT DELIVERY ORDER
# =====================================================
def pdf_words_in_rect(words, x0, y0, x1, y1):
    selected = []
    for word in words:
        wx0, wy0, wx1, wy1 = word[:4]
        cx = (wx0 + wx1) / 2
        cy = (wy0 + wy1) / 2
        if x0 <= cx < x1 and y0 <= cy < y1:
            selected.append(word)
    selected.sort(key=lambda word: (word[1], word[0]))
    return clean(" ".join(word[4] for word in selected))


def extract_flexport_delivery_order(words, page_width, page_height):
    fields = empty_fields()
    fields["Document Type"] = "Delivery Order"
    sx = page_width / 612.0
    sy = page_height / 792.0

    def box(x0, y0, x1, y1):
        return pdf_words_in_rect(words, x0*sx, y0*sy, x1*sx, y1*sy)

    fields["Ship From"] = box(190, 88, 455, 128)
    fields["Date"] = box(385, 139, 445, 160)
    fields["Our Ref. No."] = box(465, 139, 535, 160)
    fields["Carrier"] = box(35, 204, 255, 222)
    fields["Location"] = box(255, 204, 405, 222)
    fields["Origin/Destination Port"] = box(405, 204, 612, 222)
    fields["B/L or AWB No."] = box(35, 224, 170, 242)
    fields["Arrival/Departure Date"] = box(170, 224, 238, 242)
    fields["Free Time Exp."] = box(238, 224, 305, 242)
    fields["Delivery Type"] = box(320, 224, 545, 242)
    fields["House No."] = box(270, 244, 390, 262)
    fields["Entry-B/L No."] = box(390, 244, 490, 262)
    fields["Customer Ref. No."] = box(545, 244, 612, 262)
    fields["Deliver To"] = box(35, 268, 260, 310)
    fields["Ship To"] = fields["Deliver To"]
    fields["No. of Packages"] = box(35, 379, 108, 398)
    fields["Description of Articles"] = box(108, 379, 455, 398)
    fields["Weight"] = box(480, 379, 550, 398)
    fields["Container No."] = box(105, 409, 195, 430)
    fields["Container Size/Type"] = clean(
        f"{box(195, 409, 235, 430)} {box(235, 409, 300, 430)}"
    )
    fields["Quantity"] = box(350, 409, 410, 430)
    fields["Seal No."] = box(410, 409, 480, 430)
    return fields


# =====================================================
# EGA SHIPPING INSTRUCTION / INVOICE
# =====================================================
def extract_ega_page(text, page_number):
    fields = empty_fields()
    fields["Document Type"] = "Shipping Instruction / Invoice"

    fields["Ship From"] = block_between(
        text,
        r"\bSHIPPER\s*:",
        [r"\bCONSIGNEE1?\s*:", r"\bNOTIFY\s*:", r"\bShipping Information\b"],
    )
    fields["Ship To"] = block_between(
        text,
        r"\bCONSIGNEE1?\s*:",
        [r"\bNOTIFY\s*:", r"\bDetails\b", r"\bShipping Information\b"],
    )
    fields["Notify Party"] = block_between(
        text,
        r"\bNOTIFY\s*:",
        [r"\bDetails\b", r"\bShipping Marks\b"],
    )

    mapping = {
        "Date": [r"\bDate\s+(\d{1,2}[./-]\d{1,2}[./-]\d{2,4})"],
        "Vessel/Truck": [r"\bVessel/Truck\s+([^\n]+)"],
        "Loading Port": [r"\bLoading Port\s+([^\n]+)"],
        "Discharge Port": [r"\bDischarge Port\s+([^\n]+)"],
        "Sales Order No.": [r"\bSales order no\s+([A-Z0-9-]+)"],
        "Shipment Number": [r"\bShipment number\s+([A-Z0-9-]+)"],
        "Forwarding Agent": [r"\bForwarding Agent\s+(.+?)(?:\n\s*Shipping line|$)"],
        "Shipping Line": [r"\bShipping line\s+([^\n]+)"],
        "HS Code": [r"H\.S\.\s*Code\s*No\s*:\s*([0-9]+)"],
    }
    for field, patterns in mapping.items():
        fields[field] = first_match(text, patterns, re.IGNORECASE | re.MULTILINE | re.DOTALL)

    fields["Delivery Numbers"] = "; ".join(
        dict.fromkeys(re.findall(r"(?<!\d)(807\d{5})(?!\d)", text))
    )
    fields["Item Numbers"] = "; ".join(
        dict.fromkeys(re.findall(r"(?<!\d)(0000\d{2})(?!\d)", text))
    )
    fields["Bill of Lading Description"] = first_match(
        text, [r"Bill of Lading Description:\s*([^\n]+)"]
    )

    if re.search(r"Puerto Cortes\s+Made in United Arab Emirates", text, re.IGNORECASE):
        fields["Shipping Marks"] = "Puerto Cortes; Made in United Arab Emirates"

    fob = re.search(r"FOB VALUE:\s*([0-9,]+(?:\.[0-9]+)?)\s*([A-Z]{3})", text, re.IGNORECASE)
    if fob:
        fields["FOB Value"] = fob.group(1)
        fields["Currency"] = fob.group(2).upper()

    total = re.search(
        r"Total\s+(\d+)\s+Bundles\s+Containing\s+(\d+)\s+pieces\s+"
        r"([0-9.]+)\s*MT\s+([0-9.]+)\s*MT",
        text,
        re.IGNORECASE,
    )
    if total:
        fields["Total Bundles"] = total.group(1)
        fields["Total Pieces"] = total.group(2)
        fields["Total Net Weight"] = f"{total.group(3)} MT"
        fields["Total Gross Weight"] = f"{total.group(4)} MT"

    fields["Bill of Lading Instructions"] = block_between(
        text,
        r"\bBill of Lading Instructions\b",
        [r"\bH\.S\.Code\b", r"\bContainer details\b", r"\bPage:"],
    )

    containers = re.findall(r"\b([A-Z]{4}\d{7})\b", text)
    types = re.findall(r"\b(\d{2}FT)\b", text, re.IGNORECASE)
    seals = re.findall(r"\b(MLAE\d+)\b", text, re.IGNORECASE)
    fields["Container Numbers"] = "; ".join(dict.fromkeys(v.upper() for v in containers))
    fields["Container Types"] = "; ".join(dict.fromkeys(v.upper() for v in types))
    fields["Seal Numbers"] = "; ".join(dict.fromkeys(v.upper() for v in seals))
    total_containers = re.search(r"Total\s+(\d+)\s+Containers", text, re.IGNORECASE)
    if total_containers:
        fields["Total Containers"] = total_containers.group(1)
    return fields


def extract_ega_items(text, page_number):
    rows = []
    description = first_match(text, [r"Bill of Lading Description:\s*([^\n]+)"])
    pattern = re.compile(
        r"(?<!\d)(807\d{5})\s+(\d{6})\s+([0-9.]+)\s*MT\s+([0-9.]+)\s*MT",
        re.IGNORECASE,
    )
    for match in pattern.finditer(text):
        rows.append(
            {
                "Page Number": page_number,
                "Delivery No.": match.group(1),
                "Item No.": match.group(2),
                "Bundles": 8,
                "Pieces": 40,
                "Net Weight": f"{match.group(3)} MT",
                "Gross Weight": f"{match.group(4)} MT",
                "Shipping Port": "Puerto Cortes",
                "Country of Origin": "United Arab Emirates",
                "Bill of Lading Description": description,
            }
        )
    return rows


def extract_ega_containers(text, page_number):
    rows = []
    pattern = re.compile(
        r"(?<!\d)(807\d{5})\s+([A-Z]{4}\d{7})\s+(\d{2}FT)\s+(\d+)\s+"
        r"([0-9.]+)\s+([0-9.]+)\s+([0-9.]+)\s+([A-Z0-9]+)",
        re.IGNORECASE,
    )
    for match in pattern.finditer(text):
        rows.append(
            {
                "Page Number": page_number,
                "Delivery No.": match.group(1),
                "Container No.": match.group(2).upper(),
                "Container Type": match.group(3).upper(),
                "Bundles": match.group(4),
                "Bundle Weight": f"{match.group(5)} MT",
                "Tare Weight": f"{match.group(6)} MT",
                "Gross Weight": f"{match.group(7)} MT",
                "Seal No.": match.group(8).upper(),
            }
        )
    return rows


# =====================================================
# OPTIONAL HANDWRITING OCR
# =====================================================
DIMENSION_PATTERN = re.compile(
    r"(?<!\d)(\d{1,4})\s*[xX×*]\s*(\d{1,4})\s*[xX×*]\s*(\d{1,4})(?!\d)"
)


def normalize_dimension(value):
    match = DIMENSION_PATTERN.search(str(value or "").upper())
    if not match:
        return ""
    values = tuple(int(value) for value in match.groups())
    if not all(1 <= value <= 500 for value in values):
        return ""
    return "X".join(str(value) for value in values)


@st.cache_resource(show_spinner="Loading handwriting OCR model...")
def get_trocr():
    if torch is None or TrOCRProcessor is None or VisionEncoderDecoderModel is None:
        return None, None, None
    local_model = Path(__file__).resolve().parent / "models" / "trocr-small-handwritten"
    model_name = str(local_model) if local_model.is_dir() else "microsoft/trocr-small-handwritten"
    local_only = local_model.is_dir()
    device = "cuda" if torch.cuda.is_available() else "cpu"
    processor = TrOCRProcessor.from_pretrained(model_name, local_files_only=local_only)
    model = VisionEncoderDecoderModel.from_pretrained(
        model_name, local_files_only=local_only
    ).to(device).eval()
    return processor, model, device


def extract_handwriting(pdf_bytes, page_number):
    processor, model, device = get_trocr()
    if processor is None:
        return ""
    document = fitz.open(stream=pdf_bytes, filetype="pdf")
    try:
        image = render_page_rgb(document[page_number - 1], HANDWRITING_ZOOM)
    finally:
        document.close()
    height, width = image.shape[:2]
    crop = image[int(height * 0.56):, int(width * 0.03):int(width * 0.97)]
    pixel_values = processor(
        images=Image.fromarray(crop).convert("RGB"), return_tensors="pt"
    ).pixel_values.to(device)
    with torch.inference_mode():
        generated = model.generate(pixel_values, max_new_tokens=24, num_beams=1)
    text = processor.batch_decode(generated, skip_special_tokens=True)[0]
    return normalize_dimension(text)


# =====================================================
# PAGE AND PDF ANALYSIS
# =====================================================
def get_page_content(page):
    embedded_text = page.get_text("text", sort=True).strip()
    words = page.get_text("words", sort=True)
    compact_text = re.sub(r"\s+", "", embedded_text)
    meaningful_words = re.findall(r"[A-Za-z0-9]{2,}", embedded_text)
    if len(compact_text) >= 18 and len(meaningful_words) >= 3:
        return embedded_text, "Embedded text", [], words
    ocr_text, positioned = run_rapidocr(page)
    return ocr_text, "Printed OCR", positioned, words


def analyze_pdf(pdf_bytes, run_handwriting=False):
    document = fitz.open(stream=pdf_bytes, filetype="pdf")
    page_rows = []
    item_rows = []
    container_rows = []

    try:
        for page_number, page in enumerate(document, start=1):
            text, source, positioned, words = get_page_content(page)
            document_type = detect_document_type(text)

            is_flexport = (
                source == "Embedded text"
                and document_type == "Delivery Order"
                and "FLEXPORT" in text.upper()
                and "ENTRY-B/L" in text.upper()
            )

            if is_flexport:
                fields = extract_flexport_delivery_order(
                    words, page.rect.width, page.rect.height
                )
            elif document_type == "Shipping Instruction / Invoice":
                fields = extract_ega_page(text, page_number)
                item_rows.extend(extract_ega_items(text, page_number))
                container_rows.extend(extract_ega_containers(text, page_number))
            elif document_type == "Bill of Lading" or source == "Printed OCR":
                fields = extract_amazon_bol(text, positioned)
            else:
                fields = empty_fields()
                fields["Document Type"] = document_type

            dimension = normalize_dimension(text)
            if not dimension and run_handwriting:
                try:
                    dimension = extract_handwriting(pdf_bytes, page_number)
                except Exception:
                    dimension = ""

            if dimension:
                length, width, height = dimension.split("X")
                fields["Handwritten Text"] = dimension
                fields["Length"] = length
                fields["Width"] = width
                fields["Height"] = height

            fields["Source Type"] = "PDF"
            fields["Extracted Text"] = multiline_clean(text)
            fields["Detected Key-Value Pairs"] = extract_generic_key_values(text)

            page_rows.append(
                {
                    "Page Number": page_number,
                    "Text Source": source,
                    **fields,
                }
            )
    finally:
        document.close()

    return page_rows, item_rows, container_rows


# =====================================================
# IMAGE, SPREADSHEET, EMAIL, AND TEXT ANALYSIS
# =====================================================
def analyze_image(file_bytes):
    image = Image.open(io.BytesIO(file_bytes)).convert("RGB")
    image_rgb = np.array(image)
    text, lines = run_rapidocr_image(image_rgb)
    document_type = detect_document_type(text)
    if document_type == "Bill of Lading" and lines:
        fields = extract_amazon_bol(text, lines)
    else:
        fields = make_general_row(
            "Image", text, document_type if document_type != "PDF Document" else "Image Document"
        )
    fields["Source Type"] = "Image"
    fields["Extracted Text"] = multiline_clean(text)
    fields["Detected Key-Value Pairs"] = extract_generic_key_values(text)
    return [{"Page Number": 1, "Text Source": "Image OCR", **fields}], [], [], []


def dataframe_to_text(dataframe, max_rows=250):
    if dataframe.empty:
        return ""
    limited = dataframe.head(max_rows).fillna("").astype(str)
    return limited.to_csv(index=False, sep="\\t")


def analyze_spreadsheet(file_name, file_bytes):
    extension = Path(file_name).suffix.lower()
    page_rows = []
    table_rows = []

    if extension == ".csv":
        sheets = {"CSV": pd.read_csv(io.BytesIO(file_bytes), dtype=str, keep_default_na=False)}
    else:
        workbook = pd.ExcelFile(io.BytesIO(file_bytes))
        sheets = {
            sheet_name: pd.read_excel(
                workbook, sheet_name=sheet_name, dtype=str, keep_default_na=False
            )
            for sheet_name in workbook.sheet_names
        }

    for sheet_index, (sheet_name, dataframe) in enumerate(sheets.items(), start=1):
        dataframe = dataframe.fillna("")
        text = dataframe_to_text(dataframe)
        fields = make_general_row(
            "Spreadsheet",
            text,
            "Spreadsheet",
            **{"Sheet Name": sheet_name},
        )
        page_rows.append(
            {
                "Page Number": sheet_index,
                "Text Source": "Structured spreadsheet data",
                **fields,
            }
        )
        for row_number, (_, row) in enumerate(dataframe.iterrows(), start=2):
            record = {
                "File Name": file_name,
                "Sheet Name": sheet_name,
                "Row Number": row_number,
            }
            record.update({str(column): clean(value) for column, value in row.items()})
            table_rows.append(record)

    return page_rows, [], [], table_rows


def email_body_from_message(message):
    bodies = []
    if message.is_multipart():
        for part in message.walk():
            disposition = str(part.get("Content-Disposition", "")).lower()
            if "attachment" in disposition:
                continue
            content_type = part.get_content_type()
            if content_type not in {"text/plain", "text/html"}:
                continue
            try:
                value = part.get_content()
            except Exception:
                payload = part.get_payload(decode=True) or b""
                value = payload.decode(part.get_content_charset() or "utf-8", errors="replace")
            bodies.append(strip_html(value) if content_type == "text/html" else str(value))
    else:
        try:
            value = message.get_content()
        except Exception:
            payload = message.get_payload(decode=True) or b""
            value = payload.decode(message.get_content_charset() or "utf-8", errors="replace")
        bodies.append(strip_html(value) if message.get_content_type() == "text/html" else str(value))
    return multiline_clean("\\n".join(bodies))


def analyze_eml(file_bytes):
    message = BytesParser(policy=policy.default).parsebytes(file_bytes)
    body = email_body_from_message(message)
    attachments = [
        part.get_filename() for part in message.walk() if part.get_filename()
    ]
    fields = make_general_row(
        "Email",
        body,
        "Email Message",
        **{
            "Email Subject": message.get("Subject", ""),
            "Email From": message.get("From", ""),
            "Email To": message.get("To", ""),
            "Email Date": message.get("Date", ""),
            "Email Attachments": "; ".join(attachments),
        },
    )
    return [{"Page Number": 1, "Text Source": "Email body", **fields}], [], [], []


def analyze_msg(file_bytes):
    if extract_msg is None:
        fields = make_general_row(
            "Email", "Install extract-msg to read Outlook .msg files.", "Outlook Email"
        )
        return [{"Page Number": 1, "Text Source": "MSG dependency missing", **fields}], [], [], []
    temporary_path = None
    try:
        with tempfile.NamedTemporaryFile(suffix=".msg", delete=False) as temporary:
            temporary.write(file_bytes)
            temporary_path = temporary.name
        message = extract_msg.Message(temporary_path)
        body = multiline_clean(message.body or message.htmlBody or "")
        attachment_names = [clean(getattr(item, "longFilename", "") or getattr(item, "shortFilename", "")) for item in message.attachments]
        fields = make_general_row(
            "Email", body, "Outlook Email",
            **{
                "Email Subject": message.subject or "",
                "Email From": message.sender or "",
                "Email To": message.to or "",
                "Email Date": message.date or "",
                "Email Attachments": "; ".join(value for value in attachment_names if value),
            },
        )
        return [{"Page Number": 1, "Text Source": "Outlook email body", **fields}], [], [], []
    finally:
        if temporary_path and os.path.exists(temporary_path):
            os.remove(temporary_path)


def analyze_text(file_bytes):
    text = file_bytes.decode("utf-8", errors="replace")
    fields = make_general_row("Text", text, "Text Document")
    return [{"Page Number": 1, "Text Source": "Plain text", **fields}], [], [], []


def analyze_document(file_name, file_bytes, run_handwriting=False):
    extension = Path(file_name).suffix.lower()
    if extension == ".pdf":
        pages, items, containers = analyze_pdf(file_bytes, run_handwriting=run_handwriting)
        return pages, items, containers, []
    if extension in {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp"}:
        return analyze_image(file_bytes)
    if extension in {".xlsx", ".xls", ".csv"}:
        return analyze_spreadsheet(file_name, file_bytes)
    if extension == ".eml":
        return analyze_eml(file_bytes)
    if extension == ".msg":
        return analyze_msg(file_bytes)
    if extension == ".txt":
        return analyze_text(file_bytes)
    fields = make_general_row("Unknown", "", "Unsupported Document")
    return [{"Page Number": 1, "Text Source": "Unsupported", **fields}], [], [], []


# =====================================================
# EXCEL OUTPUT
# =====================================================
def format_sheet(worksheet):
    worksheet.freeze_panes = "A2"
    worksheet.auto_filter.ref = worksheet.dimensions
    for cells in worksheet.columns:
        width = min(max(len(str(cell.value or "")) for cell in cells) + 2, 60)
        worksheet.column_dimensions[cells[0].column_letter].width = width


def create_excel(
    page_df,
    item_df,
    container_df,
    tabular_df,
    validation_df,
    manifest_df,
):
    """Merge every output category into one Excel worksheet without changing values."""

    sections = []

    def add_section(dataframe, category):
        if dataframe is None or dataframe.empty:
            return
        section = dataframe.copy()
        section.insert(0, "Record Category", category)
        sections.append(section)

    add_section(page_df, "Extracted Record")
    add_section(item_df, "EGA Item Detail")
    add_section(container_df, "EGA Container Detail")
    add_section(tabular_df, "Spreadsheet Row")
    add_section(validation_df, "Field Validation")
    add_section(manifest_df, "Processing Manifest")

    if sections:
        combined_df = pd.concat(sections, ignore_index=True, sort=False)
        combined_df = combined_df.fillna("")
    else:
        combined_df = pd.DataFrame(
            [{"Record Category": "No Data", "Information": "No extracted data available"}]
        )

    preferred_columns = [
        "Record Category",
        "Run ID",
        "File Name",
        "Source Type",
        "Document Type",
        "Page Number",
        "Sheet Name",
        "Row Number",
        "Text Source",
        "Review Status",
        "Populated Field Count",
    ]
    ordered_columns = [
        column for column in preferred_columns if column in combined_df.columns
    ] + [
        column for column in combined_df.columns if column not in preferred_columns
    ]
    combined_df = combined_df[ordered_columns]

    output = io.BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        combined_df.to_excel(writer, sheet_name="Combined Extraction", index=False)
        worksheet = writer.sheets["Combined Extraction"]
        format_sheet(worksheet)
        worksheet.freeze_panes = "A2"
        worksheet.auto_filter.ref = worksheet.dimensions

        from openpyxl.styles import Alignment, Font, PatternFill

        header_fill = PatternFill("solid", fgColor="0B2540")
        category_fill = PatternFill("solid", fgColor="DDF3FA")
        for cell in worksheet[1]:
            cell.fill = header_fill
            cell.font = Font(color="FFFFFF", bold=True)
            cell.alignment = Alignment(horizontal="center", vertical="center")

        for row_number in range(2, worksheet.max_row + 1):
            worksheet.cell(row=row_number, column=1).fill = category_fill
            worksheet.cell(row=row_number, column=1).font = Font(bold=True, color="0B2540")

        worksheet.row_dimensions[1].height = 28

    return output.getvalue()


# =====================================================
# PERFORMANCE CACHE
# =====================================================
@st.cache_data(show_spinner=False, max_entries=40)
def analyze_document_cached(file_name, file_bytes, run_handwriting, ocr_zoom):
    global TEXT_OCR_ZOOM
    previous_zoom = TEXT_OCR_ZOOM
    TEXT_OCR_ZOOM = ocr_zoom
    try:
        return analyze_document(
            file_name,
            file_bytes,
            run_handwriting=run_handwriting,
        )
    finally:
        TEXT_OCR_ZOOM = previous_zoom


# =====================================================
# WORKSPACE AND EXPORT HELPERS
# =====================================================
def build_export_package(records_df, spreadsheet_df, validation_df, manifest_df):
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("all_extracted_records.csv", records_df.to_csv(index=False))
        archive.writestr("spreadsheet_rows.csv", spreadsheet_df.to_csv(index=False))
        archive.writestr("validation.csv", validation_df.to_csv(index=False))
        archive.writestr("processing_manifest.csv", manifest_df.to_csv(index=False))
        archive.writestr(
            "all_extracted_records.json",
            records_df.fillna("").to_json(orient="records", indent=2),
        )
    return buffer.getvalue()


def nonempty_count(row, fields):
    return sum(bool(clean(row.get(field, ""))) for field in fields)


# =====================================================
# STREAMLIT UI - TRUE SEPARATE WORKFLOW PAGES
# =====================================================
SUPPORTED_EXTENSIONS = [
    "pdf", "png", "jpg", "jpeg", "tif", "tiff", "bmp", "webp",
    "xlsx", "xls", "csv", "eml", "msg", "txt",
]

# Persistent navigation and extracted-data state.
def initialize_app_state():
    defaults = {
        "current_page": "upload",
        "extraction_complete": False,
        "uploaded_file_items": [],
        "page_df": pd.DataFrame(),
        "item_df": pd.DataFrame(),
        "container_df": pd.DataFrame(),
        "tabular_df": pd.DataFrame(),
        "manifest_df": pd.DataFrame(),
        "validation_df": pd.DataFrame(),
        "selected_fields": [],
        "output_df": pd.DataFrame(),
        "run_id": "",
        "ocr_mode_value": "Fast (recommended)",
        "run_handwriting_value": False,
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


initialize_app_state()

# Workspace sidebar removed; quality threshold remains internal.
review_threshold = 4
def go_to(page_name):
    st.session_state.current_page = page_name


# -----------------------------------------------------
# REAL NAVIGATION BUTTONS
# -----------------------------------------------------
st.markdown('<div class="workflow-bar">', unsafe_allow_html=True)
nav_1, nav_2, nav_3, nav_4 = st.columns(4)

with nav_1:
    if st.button(
        "① Upload & Extract",
        key="page_upload",
        use_container_width=True,
        type="primary" if st.session_state.current_page == "upload" else "secondary",
    ):
        go_to("upload")
        st.rerun()

with nav_2:
    if st.button(
        "② Review Fields",
        key="page_review",
        use_container_width=True,
        disabled=not st.session_state.extraction_complete,
        type="primary" if st.session_state.current_page == "review" else "secondary",
    ):
        go_to("review")
        st.rerun()

with nav_3:
    if st.button(
        "③ Results",
        key="page_results",
        use_container_width=True,
        disabled=not st.session_state.extraction_complete,
        type="primary" if st.session_state.current_page == "results" else "secondary",
    ):
        go_to("results")
        st.rerun()

with nav_4:
    if st.button(
        "④ Export",
        key="page_export",
        use_container_width=True,
        disabled=not st.session_state.extraction_complete,
        type="primary" if st.session_state.current_page == "export" else "secondary",
    ):
        go_to("export")
        st.rerun()

st.markdown('</div>', unsafe_allow_html=True)
st.markdown("<br>", unsafe_allow_html=True)


# =====================================================
# PAGE 1 - UPLOAD AND EXTRACT
# =====================================================
if st.session_state.current_page == "upload":
    st.markdown(
        """
        <div class="content-card">
            <div class="section-title">Upload &amp; Extract</div>
            <div class="section-description">
                Upload documents and run extraction.
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    upload_column, settings_column = st.columns([1.65, 1], gap="large")

    with upload_column:
        st.markdown("#### 📄 Select Documents")
        uploaded_files = st.file_uploader(
            "Drag and drop documents here",
            type=SUPPORTED_EXTENSIONS,
            accept_multiple_files=True,
            help=(
                "Supported: PDF, scanned PDF, PNG, JPG, JPEG, TIFF, BMP, WEBP, "
                "XLSX, XLS, CSV, EML, MSG, and TXT."
            ),
        )

    with settings_column:
        st.markdown("#### ⚙️ Extraction Settings")
        folder_path = st.text_input(
            "Optional local folder path",
            placeholder=r"C:\Users\Name\Downloads\Documents",
            help="Available only when the app runs on the same local computer.",
        )
        ocr_mode = st.selectbox(
            "Scanned document OCR mode",
            ["Fast (recommended)", "High accuracy"],
            index=0 if st.session_state.ocr_mode_value == "Fast (recommended)" else 1,
            help=(
                "Fast uses adaptive OCR: a low-resolution pass first, then a higher-resolution "
                "retry only when the detected text is too limited."
            ),
        )
        run_handwriting = st.checkbox(
            "Enable handwriting OCR for PDF dimensions",
            value=st.session_state.run_handwriting_value,
        )
        

    file_items = []
    seen_names = set()
    for uploaded in uploaded_files or []:
        if uploaded.name not in seen_names:
            file_items.append({"name": uploaded.name, "bytes": uploaded.getvalue()})
            seen_names.add(uploaded.name)

    if folder_path and os.path.isdir(folder_path):
        for file_name in sorted(os.listdir(folder_path)):
            extension = Path(file_name).suffix.lower().lstrip(".")
            if extension in SUPPORTED_EXTENSIONS and file_name not in seen_names:
                complete_path = os.path.join(folder_path, file_name)
                with open(complete_path, "rb") as file_handle:
                    file_items.append({"name": file_name, "bytes": file_handle.read()})
                seen_names.add(file_name)
    elif folder_path:
        st.warning("The local folder path was not found.")

    if file_items:
        st.caption(f"{len(file_items)} file(s) ready for extraction.")

        if st.button(
            "⚡ Extract Uploaded Documents",
            type="primary",
            use_container_width=True,
        ):
            selected_ocr_zoom = 0.95 if ocr_mode == "Fast (recommended)" else 2.0
            all_page_rows = []
            all_item_rows = []
            all_container_rows = []
            all_tabular_rows = []
            manifest_rows = []
            run_id = datetime.now().strftime("RUN-%Y%m%d-%H%M%S")

            with st.spinner("Reading documents and extracting information..."):
                progress_bar = st.progress(0)
                progress_message = st.empty()

                for file_index, item in enumerate(file_items, start=1):
                    progress_message.caption(
                        f"Processing {item['name']} ({file_index} of {len(file_items)})"
                    )
                    pages, items, containers, tabular = analyze_document_cached(
                        item["name"],
                        item["bytes"],
                        run_handwriting,
                        selected_ocr_zoom,
                    )
                    all_page_rows.extend(
                        {"File Name": item["name"], **row} for row in pages
                    )
                    all_item_rows.extend(
                        {"File Name": item["name"], **row} for row in items
                    )
                    all_container_rows.extend(
                        {"File Name": item["name"], **row} for row in containers
                    )
                    all_tabular_rows.extend(tabular)
                    manifest_rows.append(
                        {
                            "Run ID": run_id,
                            "File Name": item["name"],
                            "File Type": Path(item["name"]).suffix.lower().lstrip(".").upper(),
                            "File Size KB": round(len(item["bytes"]) / 1024, 1),
                            "Extracted Records": len(pages),
                            "SHA-256": hashlib.sha256(item["bytes"]).hexdigest(),
                            "Processed At": datetime.now().isoformat(timespec="seconds"),
                        }
                    )
                    progress_bar.progress(file_index / len(file_items))

                progress_bar.empty()
                progress_message.empty()

            page_df = pd.DataFrame(all_page_rows)
            item_df = pd.DataFrame(all_item_rows)
            container_df = pd.DataFrame(all_container_rows)
            tabular_df = pd.DataFrame(all_tabular_rows)
            manifest_df = pd.DataFrame(manifest_rows)

            ordered_columns = ["File Name", "Page Number", "Text Source"] + ALL_FIELDS
            for column in ordered_columns:
                if column not in page_df.columns:
                    page_df[column] = ""
            page_df = page_df[ordered_columns]

            quality_fields = [
                field for field in ALL_FIELDS
                if field not in {"Extracted Text", "Detected Key-Value Pairs", "Source Type"}
            ]
            page_df["Populated Field Count"] = page_df.apply(
                lambda row: nonempty_count(row, quality_fields),
                axis=1,
            )
            page_df["Review Status"] = np.where(
                page_df["Populated Field Count"] >= review_threshold,
                "AUTO-READY",
                "REVIEW NEEDED",
            )
            page_df["Run ID"] = run_id

            automatically_detected_fields = [
                field for field in ALL_FIELDS
                if page_df[field].fillna("").astype(str).str.strip().ne("").any()
            ]

            st.session_state.uploaded_file_items = file_items
            st.session_state.page_df = page_df
            st.session_state.item_df = item_df
            st.session_state.container_df = container_df
            st.session_state.tabular_df = tabular_df
            st.session_state.manifest_df = manifest_df
            st.session_state.selected_fields = automatically_detected_fields
            st.session_state.output_df = pd.DataFrame()
            st.session_state.validation_df = pd.DataFrame()
            st.session_state.run_id = run_id
            st.session_state.ocr_mode_value = ocr_mode
            st.session_state.run_handwriting_value = run_handwriting
            st.session_state.extraction_complete = True
            st.session_state.current_page = "review"
            st.rerun()
    else:
        st.info("Upload one or more supported files to begin.")


# =====================================================
# PAGE 2 - REVIEW FIELDS
# =====================================================
elif st.session_state.current_page == "review":
    page_df = st.session_state.page_df.copy()
    file_items = st.session_state.uploaded_file_items

    st.markdown(
        """
        <div class="content-card">
            <div class="section-title">Review Fields</div>
            <div class="section-description">
                Review extracted values and choose the fields that should appear in Results and Export.
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    preview_column, fields_column = st.columns([1.05, 1], gap="large")

    with preview_column:
        st.markdown('<div class="preview-heading">📑 Source Preview</div>', unsafe_allow_html=True)
        selected_name = st.selectbox(
            "Preview Document",
            [item["name"] for item in file_items],
        )
        selected_item = next(item for item in file_items if item["name"] == selected_name)
        selected_rows = page_df[page_df["File Name"] == selected_name]
        selected_record = st.number_input(
            "Page / Sheet / Record",
            min_value=1,
            max_value=max(1, len(selected_rows)),
            value=1,
            step=1,
        )
        extension = Path(selected_name).suffix.lower()
        if extension == ".pdf":
            document = fitz.open(stream=selected_item["bytes"], filetype="pdf")
            try:
                page_index = min(int(selected_record) - 1, len(document) - 1)
                pix = document[page_index].get_pixmap(
                    matrix=fitz.Matrix(1.1, 1.1),
                    colorspace=fitz.csRGB,
                    alpha=False,
                )
                st.image(
                    Image.open(io.BytesIO(pix.tobytes("png"))),
                    use_container_width=True,
                )
            finally:
                document.close()
        elif extension in {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp"}:
            st.image(
                Image.open(io.BytesIO(selected_item["bytes"])),
                use_container_width=True,
            )
        elif extension in {".xlsx", ".xls", ".csv"}:
            table_df = st.session_state.tabular_df
            matching = table_df[table_df["File Name"] == selected_name] if not table_df.empty else pd.DataFrame()
            st.dataframe(matching.head(100), use_container_width=True, hide_index=True)
        else:
            row_index = min(int(selected_record) - 1, len(selected_rows) - 1)
            st.text_area(
                "Content",
                selected_rows.iloc[row_index].get("Extracted Text", ""),
                height=520,
                disabled=True,
            )

    with fields_column:
        st.markdown('<div class="preview-heading">🔎 Extracted Information</div>', unsafe_allow_html=True)
        row_index = min(int(selected_record) - 1, len(selected_rows) - 1)
        first_row = selected_rows.iloc[row_index]
        preview_df = pd.DataFrame(
            [
                {"Field": field, "Extracted Value": first_row.get(field, "")}
                for field in ALL_FIELDS
                if clean(first_row.get(field, ""))
            ]
        )
        if preview_df.empty:
            st.warning("No supported values were detected in this record.")
        else:
            st.dataframe(preview_df, use_container_width=True, hide_index=True, height=560)

    st.markdown("### Field Selection")
    field_mode = st.radio(
        "Choose how fields should be selected",
        ["Automatically detected fields", "Select fields manually"],
        horizontal=True,
    )

    detected_fields = [
        field for field in ALL_FIELDS
        if page_df[field].fillna("").astype(str).str.strip().ne("").any()
    ]
    current_selection = st.session_state.selected_fields or detected_fields

    if field_mode == "Automatically detected fields":
        selected_fields = st.multiselect(
            "Detected Fields",
            ALL_FIELDS,
            default=[field for field in current_selection if field in ALL_FIELDS],
        )
    else:
        selected_fields = st.multiselect(
            "Select Output Fields",
            ALL_FIELDS,
            default=[field for field in current_selection if field in ALL_FIELDS],
        )

    st.session_state.selected_fields = selected_fields

    left_action, right_action = st.columns([1, 1])
    with left_action:
        if st.button("← Back to Upload", use_container_width=True):
            go_to("upload")
            st.rerun()
    with right_action:
        if st.button("Continue to Results →", type="primary", use_container_width=True):
            go_to("results")
            st.rerun()


# =====================================================
# PAGE 3 - RESULTS
# =====================================================
elif st.session_state.current_page == "results":
    page_df = st.session_state.page_df.copy()
    selected_fields = st.session_state.selected_fields or [
        field for field in ALL_FIELDS
        if page_df[field].fillna("").astype(str).str.strip().ne("").any()
    ]

    display_columns = [
        "Run ID", "File Name", "Page Number", "Text Source",
        "Review Status", "Populated Field Count",
    ] + [
        field for field in ALL_FIELDS
        if field in selected_fields and field in page_df.columns
    ]
    output_df = page_df[display_columns].copy()

    validation_rows = []
    for field in selected_fields:
        if field not in output_df.columns:
            continue
        extracted_count = int(
            output_df[field].fillna("").astype(str).str.strip().ne("").sum()
        )
        status = (
            "PASS" if extracted_count == len(output_df)
            else "PARTIAL" if extracted_count
            else "REVIEW"
        )
        coverage = extracted_count / len(output_df) * 100 if len(output_df) else 0
        validation_rows.append(
            {
                "Field": field,
                "Rows Extracted": extracted_count,
                "Total Records": len(output_df),
                "Coverage": f"{coverage:.1f}%",
                "Status": status,
            }
        )
    validation_df = pd.DataFrame(validation_rows)
    st.session_state.validation_df = validation_df

    st.markdown(
        """
        <div class="content-card">
            <div class="section-title">Results</div>
            <div class="section-description">
                This page shows only the application's extracted output and quality information.
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Files", output_df["File Name"].nunique())
    m2.metric("Extracted Records", len(output_df))
    m3.metric("Selected Fields", len(selected_fields))
    m4.metric("Needs Review", int(output_df["Review Status"].eq("REVIEW NEEDED").sum()))

    (
        dashboard_tab,
        records_tab,
        structured_tab,
        item_tab,
        container_tab,
        audit_tab,
        validation_tab,
    ) = st.tabs(
        [
            "📈 Batch Dashboard",
            "📋 All Records",
            "📊 Structured Rows",
            "📦 EGA Items",
            "🚢 EGA Containers",
            "🧾 Audit Manifest",
            "✅ Validation",
        ]
    )

    with dashboard_tab:
        source_summary = (
            page_df.groupby(["Source Type", "Document Type"], dropna=False)
            .size()
            .reset_index(name="Records")
        )
        st.markdown("#### Document Mix")
        st.dataframe(source_summary, use_container_width=True, hide_index=True)
        st.markdown("#### Field Coverage")
        st.dataframe(validation_df, use_container_width=True, hide_index=True)

    with records_tab:
        search_text = st.text_input(
            "Search extracted records",
            placeholder="Search shipment, container, port, party, file, or any value",
        )
        filtered_df = output_df.copy()
        if search_text:
            mask = filtered_df.astype(str).apply(
                lambda column: column.str.contains(search_text, case=False, na=False)
            ).any(axis=1)
            filtered_df = filtered_df[mask]
        edited_output_df = st.data_editor(
            filtered_df,
            use_container_width=True,
            hide_index=True,
            height=600,
            num_rows="fixed",
            key="final_results_editor",
        )
        st.session_state.output_df = edited_output_df

    with structured_tab:
        if not st.session_state.tabular_df.empty:
            structured_df = st.session_state.tabular_df.copy()
            st.caption("Original rows preserved from uploaded Excel or CSV files.")
        else:
            structured_df = output_df.drop(
                columns=[
                    column for column in ["Extracted Text", "Detected Key-Value Pairs"]
                    if column in output_df.columns
                ]
            )
            structured_df = structured_df[
                [
                    column for column in structured_df.columns
                    if structured_df[column].fillna("").astype(str).str.strip().ne("").any()
                ]
            ]
            st.caption("Structured fields extracted from PDF, image, email, or text records.")
        st.dataframe(structured_df, use_container_width=True, hide_index=True, height=600)

    with item_tab:
        if st.session_state.item_df.empty:
            st.info("No EGA item-detail rows were found.")
        else:
            st.dataframe(st.session_state.item_df, use_container_width=True, hide_index=True)

    with container_tab:
        if st.session_state.container_df.empty:
            st.info("No EGA container-detail rows were found.")
        else:
            st.dataframe(st.session_state.container_df, use_container_width=True, hide_index=True)

    with audit_tab:
        st.dataframe(st.session_state.manifest_df, use_container_width=True, hide_index=True)

    with validation_tab:
        st.dataframe(validation_df, use_container_width=True, hide_index=True)

    left_action, right_action = st.columns([1, 1])
    with left_action:
        if st.button("← Back to Review", use_container_width=True):
            go_to("review")
            st.rerun()
    with right_action:
        if st.button("Continue to Export →", type="primary", use_container_width=True):
            if st.session_state.output_df.empty:
                st.session_state.output_df = output_df
            go_to("export")
            st.rerun()


# =====================================================
# PAGE 4 - EXPORT
# =====================================================
elif st.session_state.current_page == "export":
    page_df = st.session_state.page_df.copy()
    selected_fields = st.session_state.selected_fields
    display_columns = [
        "Run ID", "File Name", "Page Number", "Text Source",
        "Review Status", "Populated Field Count",
    ] + [
        field for field in ALL_FIELDS
        if field in selected_fields and field in page_df.columns
    ]
    output_df = (
        st.session_state.output_df.copy()
        if not st.session_state.output_df.empty
        else page_df[display_columns].copy()
    )

    validation_df = st.session_state.validation_df.copy()
    if validation_df.empty:
        validation_rows = []
        for field in selected_fields:
            if field not in output_df.columns:
                continue
            count = int(output_df[field].fillna("").astype(str).str.strip().ne("").sum())
            validation_rows.append(
                {
                    "Field": field,
                    "Rows Extracted": count,
                    "Total Records": len(output_df),
                    "Coverage": f"{(count / len(output_df) * 100) if len(output_df) else 0:.1f}%",
                    "Status": "PASS" if count == len(output_df) else "PARTIAL" if count else "REVIEW",
                }
            )
        validation_df = pd.DataFrame(validation_rows)

    st.markdown(
        """
        <div class="content-card">
            <div class="section-title">Export</div>
            <div class="section-description">
                Download the final extracted information. The Excel workbook contains one
                worksheet named Combined Extraction.
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.success(
        f"{len(output_df)} extracted record(s) are ready for download."
    )

    export_1, export_2, export_3 = st.columns(3)
    with export_1:
        st.download_button(
            "📥 Download One-Sheet Excel",
            data=create_excel(
                output_df,
                st.session_state.item_df,
                st.session_state.container_df,
                st.session_state.tabular_df,
                validation_df,
                st.session_state.manifest_df,
            ),
            file_name="Complete_Combined_Extraction_One_Sheet.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            use_container_width=True,
        )

    with export_2:
        st.download_button(
            "📄 Download JSON",
            data=output_df.fillna("").to_json(orient="records", indent=2),
            file_name="all_extracted_records.json",
            mime="application/json",
            use_container_width=True,
        )

    with export_3:
        st.download_button(
            "📦 Download Audit Package",
            data=build_export_package(
                output_df,
                st.session_state.tabular_df,
                validation_df,
                st.session_state.manifest_df,
            ),
            file_name=f"SmartDoc_{st.session_state.run_id}_audit_package.zip",
            mime="application/zip",
            use_container_width=True,
        )

    if st.button("← Back to Results"):
        go_to("results")
        st.rerun()


st.markdown(
    """
    <div class="app-footer">
        SmartDoc Intelligence Hub &nbsp;•&nbsp; Separate workflow pages &nbsp;•&nbsp;
        Preserved extraction logic &nbsp;•&nbsp; One-sheet Excel export
    </div>
    """,
    unsafe_allow_html=True,
)
